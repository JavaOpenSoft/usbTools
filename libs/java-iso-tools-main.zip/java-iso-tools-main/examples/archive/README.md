This example shows how to create an virtual ISO, add files to it, then save it to a file.
