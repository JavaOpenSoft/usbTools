This is an example of how to Read an iso and store the files into a folder.
