#!/bin/bash

rm -f /mnt/rd/*.iso
